var lightMovePageReader = (function(exports) {
	Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
	//#region src/content/pageReader/extractedCompany.ts
	var EMPTY_EXTRACTED_COMPANY = {
		companyName: null,
		linkedinUrl: null
	};
	/**
	* Folds extractor results together, first non-empty value per field, most specific reader first.
	*
	* Written out field by field on purpose: adding a field to `ExtractedCompany` fails the build here
	* until it is merged too, rather than silently arriving as null on every page.
	*/
	function mergeExtracted(results) {
		return {
			companyName: firstAnswer$1(results, "companyName"),
			linkedinUrl: firstAnswer$1(results, "linkedinUrl")
		};
	}
	/** The first extractor with something to say about this field, or nothing if none had. */
	function firstAnswer$1(results, field) {
		for (const result of results) {
			const value = result[field];
			if (value !== null && value !== void 0 && value !== "") return value;
		}
		return EMPTY_EXTRACTED_COMPANY[field];
	}
	/**
	* Drops the fields an extractor had nothing to say about.
	*
	* Load-bearing for the merge, not tidiness: an explicit null still counts as "this extractor answered"
	* and would stop a later, broader extractor filling the gap.
	*/
	function withoutEmpty(fields) {
		return Object.fromEntries(Object.entries(fields).filter(([, value]) => value !== null && value !== void 0 && value !== ""));
	}
	/**
	* A page-supplied URL, or nothing unless it is http(s). Hostile text that gets *persisted*, so a
	* `javascript:` href planted today would detonate on whichever future screen renders it as a link.
	*/
	function httpUrlOrNull(value, base) {
		const candidate = cleanText(value);
		if (!candidate) return null;
		if (isAbsolute(candidate)) return isHttp(parseOrNull(candidate)) ? candidate : null;
		if (hasHostShape(candidate)) return candidate;
		const resolved = base ? parseOrNull(candidate, base) : null;
		return isHttp(resolved) ? resolved.href : null;
	}
	function parseOrNull(value, base) {
		try {
			return new URL(value, base);
		} catch {
			return null;
		}
	}
	function isHttp(url) {
		return url !== null && (url.protocol === "https:" || url.protocol === "http:");
	}
	/** A scheme-less host, "acme.ae" or "Acme.AE/about" — never a path, and never a scheme in disguise. */
	function hasHostShape(value) {
		const host = parseOrNull(`https://${value}`)?.hostname;
		return host !== void 0 && host.includes(".") && value.toLowerCase().startsWith(host);
	}
	function isAbsolute(value) {
		return /^[a-z][a-z0-9+.-]*:/i.test(value) || value.startsWith("//");
	}
	/** Whether a URL is a LinkedIn company page, by parsed host — never a substring of the whole URL. */
	function isLinkedInCompanyUrl(value) {
		if (!value) return false;
		try {
			const url = new URL(value);
			return /(^|\.)linkedin\.com$/i.test(url.hostname) && url.pathname.startsWith("/company/");
		} catch {
			return false;
		}
	}
	/** Collapses whitespace and trims; returns null for what is left of an empty string. */
	function cleanText(value) {
		if (!value) return null;
		const collapsed = value.replace(/\s+/g, " ").trim();
		return collapsed.length > 0 ? collapsed : null;
	}
	//#endregion
	//#region src/content/pageReader/extractedPerson.ts
	var EMPTY_EXTRACTED_PERSON = {
		fullName: null,
		linkedinUrl: null
	};
	/**
	* Folds extractor results together, first non-empty value per field, most specific extractor first.
	*
	* Written out field by field for the reason `mergeExtracted` is: adding a field fails the build here
	* until it is merged too, rather than silently arriving as null on every page.
	*/
	function mergeExtractedPerson(results) {
		return {
			fullName: firstAnswer(results, "fullName"),
			linkedinUrl: firstAnswer(results, "linkedinUrl")
		};
	}
	function firstAnswer(results, field) {
		for (const result of results) {
			const value = result[field];
			if (value !== null && value !== void 0 && value !== "") return value;
		}
		return EMPTY_EXTRACTED_PERSON[field];
	}
	/** Whether a URL is a LinkedIn member profile, by parsed host — never a substring of the whole URL. */
	function isLinkedInProfileUrl(value) {
		if (!value) return false;
		try {
			const url = new URL(value);
			return /(^|\.)linkedin\.com$/i.test(url.hostname) && url.pathname.startsWith("/in/");
		} catch {
			return false;
		}
	}
	//#endregion
	//#region src/content/pageReader/extractors/dom.ts
	/** Reading a `Document`, shared by every extractor. Nothing here knows what is being looked for. */
	function textOf(document, selector) {
		return document.querySelector(selector)?.textContent ?? null;
	}
	//#endregion
	//#region src/content/pageReader/extractors/linkedInCompanyExtractor.ts
	/**
	* `linkedin.com/company/*` — the company's name, and nothing more. Class names are generated and
	* churn per deploy, so the chain ends at the tab title, which every layout still carries.
	*/
	var linkedInCompanyExtractor = (document) => {
		if (!isLinkedInCompanyPage(document)) return {};
		return withoutEmpty({
			companyName: cleanText(textOf(document, "h1[class*=\"org-top-card\"]") ?? textOf(document, "main h1")) ?? nameFromDocumentTitle$1(document),
			linkedinUrl: canonicalCompanyUrl(document)
		});
	};
	/** "Al Rawabi Dairy Company | LinkedIn", with the notification count and the suffix dropped. */
	function nameFromDocumentTitle$1(document) {
		const titleText = cleanText(document.title)?.replace(/^\(\d+\+?\)\s*/, "").replace(/\s*[|│]\s*LinkedIn\s*$/i, "").replace(/:\s*(about|jobs|people|posts|life|overview)\s*$/i, "");
		const name = cleanText(titleText);
		return name && !/^(linkedin|feed|home|messaging|notifications|my network|jobs|search)$/i.test(name) ? name : null;
	}
	/**
	* Keyed on the host the browser actually loaded, never on `canonical`/`og:url` — those are page-supplied,
	* so any site could otherwise declare itself a LinkedIn company page and be read by this extractor.
	*/
	function isLinkedInCompanyPage(document) {
		const hostname = document.location?.hostname ?? "";
		return /(^|\.)linkedin\.com$/i.test(hostname) && (document.location?.pathname ?? "").startsWith("/company/");
	}
	function canonicalCompanyUrl(document) {
		const candidates = [
			document.querySelector("link[rel=\"canonical\"]")?.getAttribute("href"),
			document.querySelector("meta[property=\"og:url\"]")?.getAttribute("content"),
			document.location?.href
		];
		for (const candidate of candidates) {
			const url = httpUrlOrNull(candidate);
			if (url && isLinkedInCompanyUrl(url)) return url;
		}
		return null;
	}
	//#endregion
	//#region src/content/pageReader/extractors/linkedInProfileExtractor.ts
	/**
	* `linkedin.com/in/*` — the name off a profile, and nothing more. The signed-in 2025 layout renders
	* no `h1`, hashes every class name per deploy and serves no JSON-LD, so anything richer than the
	* name proved unshippable; the tab title is the one anchor every layout still offers.
	*/
	var linkedInProfileExtractor = (document) => {
		if (!isLinkedInProfilePage(document)) return {};
		return withoutEmpty({
			fullName: cleanText(textOf(document, "h1[class*=\"top-card-layout__title\"]") ?? textOf(document, "main h1")) ?? nameFromDocumentTitle(document),
			linkedinUrl: canonicalProfileUrl(document)
		});
	};
	/**
	* The person's name, out of the tab title: "(3) Amira Haddad - Group CFO - Al Rawabi | LinkedIn",
	* where the count is unread notifications and the separator has shipped as a hyphen, an en dash and
	* an em dash. The most stable signal there is — it survives every layout so far.
	*/
	function nameFromDocumentTitle(document) {
		const name = ((cleanText(document.title)?.replace(/^\(\d+\+?\)\s*/, "").replace(/\s*[|│]\s*LinkedIn\s*$/i, ""))?.split(/\s+[-–—]\s+/).map((part) => part.trim()).filter(Boolean) ?? [])[0] ?? null;
		return name && !isLinkedInSectionTitle(name) ? name : null;
	}
	/**
	* The titles LinkedIn's own sections carry. It rewrites the title while a pushState navigation is in
	* flight — plain "LinkedIn", or the section being left — so without this the panel offers a person
	* named "Feed" for the moment between one profile and the next.
	*/
	function isLinkedInSectionTitle(name) {
		return /^(linkedin|feed|home|messaging|notifications|my network|jobs|search|sales navigator)$/i.test(name);
	}
	/**
	* Keyed on the host the browser actually loaded, never on `canonical`/`og:url` — those are page-supplied,
	* so any site could otherwise declare itself a LinkedIn profile and be read by this extractor.
	*/
	function isLinkedInProfilePage(document) {
		const hostname = document.location?.hostname ?? "";
		return /(^|\.)linkedin\.com$/i.test(hostname) && (document.location?.pathname ?? "").startsWith("/in/");
	}
	function canonicalProfileUrl(document) {
		const candidates = [
			document.querySelector("link[rel=\"canonical\"]")?.getAttribute("href"),
			document.querySelector("meta[property=\"og:url\"]")?.getAttribute("content"),
			document.location?.href
		];
		for (const candidate of candidates) {
			const url = httpUrlOrNull(candidate);
			if (url && isLinkedInProfileUrl(url)) return url;
		}
		return null;
	}
	//#endregion
	//#region src/content/pageReader/readPageSubject.ts
	/**
	* The one thing injected into a page. LinkedIn only, and the URL is the whole classification —
	* `/in/` is a person, `/company/` is a company, and anything else (the feed, search, jobs) is
	* "unknown", which the worker answers with "open a profile or company page" rather than a guess.
	*/
	function readPageSubject(document) {
		return {
			subject: classify(document),
			person: mergeExtractedPerson([linkedInProfileExtractor(document)]),
			company: mergeExtracted([linkedInCompanyExtractor(document)]),
			pageUrl: document.location?.href ?? "",
			declaredUrl: declaredUrlOf(document)
		};
	}
	function classify(document) {
		const pathname = document.location?.pathname ?? "";
		if (!/(^|\.)linkedin\.com$/i.test(document.location?.hostname ?? "")) return "unknown";
		if (pathname.startsWith("/in/")) return "person";
		return pathname.startsWith("/company/") ? "company" : "unknown";
	}
	function declaredUrlOf(document) {
		const candidates = [document.querySelector("link[rel=\"canonical\"]")?.getAttribute("href"), document.querySelector("meta[property=\"og:url\"]")?.getAttribute("content")];
		for (const candidate of candidates) {
			const url = httpUrlOrNull(candidate);
			if (url) return url;
		}
		return null;
	}
	//#endregion
	exports.readPageSubject = readPageSubject;
	return exports;
})({});
lightMovePageReader.readPageSubject(document);
